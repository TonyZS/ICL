package AST;
import value.IntegerV;

public interface ASTNode {

	public IntegerV eval(Environment<IntegerV> e);
	
}

