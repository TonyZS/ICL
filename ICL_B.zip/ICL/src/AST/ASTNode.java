package AST;

public interface ASTNode {

	public int eval(Environment<Integer> e);

	// public void compile();

}
