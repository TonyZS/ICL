package AST;
import value.IntegerV;

public class ASTUminus implements ASTNode {

	ASTNode lhs, rhs;

	public IntegerV eval(Environment<IntegerV> e) {
		IntegerV v1 = lhs.eval(e);


		return new IntegerV(v1.getIntegerV()*-1);
	}

	public ASTUminus(ASTNode l) {
		lhs = l;
	}
}
