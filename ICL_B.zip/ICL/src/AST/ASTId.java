package AST;
import value.IntegerV;

public class ASTId implements ASTNode {

	String id;

	public IntegerV eval(Environment<IntegerV> e) {
		return e.find(id);
	}

	public ASTId(String value) {
		id = value;
	}

}