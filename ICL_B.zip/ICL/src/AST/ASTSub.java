package AST;
import value.IntegerV;

public class ASTSub implements ASTNode {

	ASTNode lhs, rhs;

	public IntegerV eval(Environment<IntegerV> e) {
		IntegerV v1 = lhs.eval(e);
		IntegerV v2 = rhs.eval(e);
		return new IntegerV(v1.getIntegerV() - v2.getIntegerV());
	}

	public ASTSub(ASTNode l, ASTNode r) {
		lhs = l;
		rhs = r;
	}
}
