package AST;
import value.IntegerV;

public class ASTNum implements ASTNode {

	int val;

	public IntegerV eval(Environment<IntegerV> e) {
		return new IntegerV(val);
	}

	public ASTNum(int n) {
		val = n;
	}

}
