package AST;
import value.IntegerV;

public class ASTPlus implements ASTNode {

	ASTNode lhs, rhs;

	public IntegerV eval(Environment<IntegerV> e) {
		IntegerV v1 = lhs.eval(e);
		IntegerV v2 = rhs.eval(e);
		return new IntegerV(v1.getIntegerV() + v2.getIntegerV());
	}

	public ASTPlus(ASTNode l, ASTNode r) {
		lhs = l;
		rhs = r;
	}
}
