package AST;

import compile.CodeBlock;

public class ASTDiv implements ASTNode {

	private ASTNode lhs, rhs;

	public int eval(Environment<Integer> e) {
		int v1 = lhs.eval(e);
		int v2 = rhs.eval(e);
		return v1 / v2;
	}

	public ASTDiv(ASTNode l, ASTNode r) {
		lhs = l;
		rhs = r;
	}

	@Override
	public void compile(CodeBlock block, Environment<Pair<Integer, String>> e) {
		lhs.compile(block,e);
		rhs.compile(block,e);
		String s = "idiv";
		block.addinstruction(s);

	}
}
