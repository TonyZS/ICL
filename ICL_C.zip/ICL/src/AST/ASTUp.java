package AST;

import compile.CodeBlock;

public class ASTUp implements ASTNode {

	String id;

	public int eval(Environment<Integer> e) {
		
		return e.endScope().find(id);
	}

	public ASTUp(String id) {
		this.id = id;
	}

	public void compile(CodeBlock block, Environment<Pair<Integer, String>> e) {
		
		
	}

}
