package AST;
import compile.*;

public interface ASTNode {

	public int eval(Environment<Integer> e);

	 public void compile(CodeBlock block, Environment<Pair<Integer, String>> e);

}
