package AST;

import compile.CodeBlock;

public class ASTUminus implements ASTNode {

	ASTNode lhs;

	public int eval(Environment<Integer> e) {
		int v1 = lhs.eval(e);


		return -v1;
	}

	public ASTUminus(ASTNode l) {
		lhs = l;
	}

	@Override
	public void compile(CodeBlock block, Environment<Pair<Integer, String>> e) {
		lhs.compile(block, e);
		String s = "ineg";
		block.addinstruction(s);
			
		}
}
