package value;

public class IntegerV {

	private int value;
	
	public IntegerV(int v) {
		value = v;
	}
	
	public int getIntegerV() {
		return value;
	}
}
