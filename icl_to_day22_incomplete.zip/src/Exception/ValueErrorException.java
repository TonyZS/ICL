package Exception;

@SuppressWarnings("serial")
public class ValueErrorException extends Exception {

	public ValueErrorException(String messageError) {
		super(messageError);

	}

}
