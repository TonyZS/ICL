package AST;

public interface IValue {
	public String toString();
	
	Object getValue();
}
