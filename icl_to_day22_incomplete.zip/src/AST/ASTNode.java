package AST;
import Exception.ValueErrorException;
import compile.*;

public interface ASTNode {

	public IValue eval(Environment<IValue> e)throws ValueErrorException;

	 public void compile(CodeBlock block, Environment<Pair<Integer, String>> e) ;

}
