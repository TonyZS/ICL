package AST;

import Exception.ValueErrorException;
import compile.CodeBlock;

public class ASTUminus implements ASTNode {

	ASTNode lhs;

	@Override
	public IValue eval(Environment<IValue> e) throws ValueErrorException {
		IValue v1 = lhs.eval(e);

		if (v1 instanceof VInt) {
			return new VInt(-(((VInt)v1).getValue()));
		} else {
			throw new ValueErrorException("-: argument is not an integer");
		}
	}

	public ASTUminus(ASTNode l) {
		lhs = l;
	}

	@Override
	public void compile(CodeBlock block, Environment<Pair<Integer, String>> e) {
		lhs.compile(block, e);
		String s = "ineg";
		block.addinstruction(s);

	}
}
