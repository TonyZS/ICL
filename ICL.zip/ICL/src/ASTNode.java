public interface ASTNode {

    int eval();
	
}

